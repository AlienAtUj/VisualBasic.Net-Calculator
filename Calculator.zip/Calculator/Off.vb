﻿Public Class Off
    Public ReadOnly Property Message As String

    Public Sub New(Name As String)
        Me.Message = Name
    End Sub

End Class

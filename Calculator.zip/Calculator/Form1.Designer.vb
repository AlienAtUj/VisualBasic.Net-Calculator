﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        txtDisplay = New TextBox()
        btnClear = New Button()
        btnFive = New Button()
        btnDivide = New Button()
        btnNine = New Button()
        btnEight = New Button()
        btnZero = New Button()
        btnEqualTo = New Button()
        btnDot = New Button()
        btnSeven = New Button()
        btnFour = New Button()
        btnOne = New Button()
        btnOff = New Button()
        btnOn = New Button()
        btnSix = New Button()
        btnMultiply = New Button()
        btnMinus = New Button()
        btnThree = New Button()
        btnTwo = New Button()
        btnAdd = New Button()
        SuspendLayout()
        ' 
        ' txtDisplay
        ' 
        txtDisplay.Location = New Point(12, 12)
        txtDisplay.Multiline = True
        txtDisplay.Name = "txtDisplay"
        txtDisplay.Size = New Size(318, 64)
        txtDisplay.TabIndex = 1
        ' 
        ' btnClear
        ' 
        btnClear.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(12, 82)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(156, 44)
        btnClear.TabIndex = 9
        btnClear.Text = "C"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnFive
        ' 
        btnFive.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnFive.Location = New Point(93, 181)
        btnFive.Name = "btnFive"
        btnFive.Size = New Size(75, 44)
        btnFive.TabIndex = 10
        btnFive.Text = "5"
        btnFive.UseVisualStyleBackColor = True
        ' 
        ' btnDivide
        ' 
        btnDivide.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnDivide.Location = New Point(255, 281)
        btnDivide.Name = "btnDivide"
        btnDivide.Size = New Size(75, 44)
        btnDivide.TabIndex = 11
        btnDivide.Text = "/"
        btnDivide.UseVisualStyleBackColor = True
        ' 
        ' btnNine
        ' 
        btnNine.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnNine.Location = New Point(174, 231)
        btnNine.Name = "btnNine"
        btnNine.Size = New Size(75, 44)
        btnNine.TabIndex = 13
        btnNine.Text = "9"
        btnNine.UseVisualStyleBackColor = True
        ' 
        ' btnEight
        ' 
        btnEight.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnEight.Location = New Point(93, 231)
        btnEight.Name = "btnEight"
        btnEight.Size = New Size(75, 44)
        btnEight.TabIndex = 14
        btnEight.Text = "8"
        btnEight.UseVisualStyleBackColor = True
        ' 
        ' btnZero
        ' 
        btnZero.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnZero.Location = New Point(93, 281)
        btnZero.Name = "btnZero"
        btnZero.Size = New Size(75, 44)
        btnZero.TabIndex = 15
        btnZero.Text = "0"
        btnZero.UseVisualStyleBackColor = True
        ' 
        ' btnEqualTo
        ' 
        btnEqualTo.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnEqualTo.Location = New Point(174, 283)
        btnEqualTo.Name = "btnEqualTo"
        btnEqualTo.Size = New Size(75, 44)
        btnEqualTo.TabIndex = 17
        btnEqualTo.Text = "="
        btnEqualTo.UseVisualStyleBackColor = True
        ' 
        ' btnDot
        ' 
        btnDot.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnDot.Location = New Point(12, 281)
        btnDot.Name = "btnDot"
        btnDot.Size = New Size(75, 44)
        btnDot.TabIndex = 20
        btnDot.Text = "."
        btnDot.UseVisualStyleBackColor = True
        ' 
        ' btnSeven
        ' 
        btnSeven.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSeven.Location = New Point(12, 231)
        btnSeven.Name = "btnSeven"
        btnSeven.Size = New Size(75, 44)
        btnSeven.TabIndex = 21
        btnSeven.Text = "7"
        btnSeven.UseVisualStyleBackColor = True
        ' 
        ' btnFour
        ' 
        btnFour.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnFour.Location = New Point(12, 181)
        btnFour.Name = "btnFour"
        btnFour.Size = New Size(75, 44)
        btnFour.TabIndex = 22
        btnFour.Text = "4"
        btnFour.UseVisualStyleBackColor = True
        ' 
        ' btnOne
        ' 
        btnOne.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnOne.Location = New Point(12, 131)
        btnOne.Name = "btnOne"
        btnOne.Size = New Size(75, 44)
        btnOne.TabIndex = 23
        btnOne.Text = "1"
        btnOne.UseVisualStyleBackColor = True
        ' 
        ' btnOff
        ' 
        btnOff.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnOff.Location = New Point(174, 82)
        btnOff.Name = "btnOff"
        btnOff.Size = New Size(75, 44)
        btnOff.TabIndex = 24
        btnOff.Text = "Off"
        btnOff.UseVisualStyleBackColor = True
        ' 
        ' btnOn
        ' 
        btnOn.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnOn.Location = New Point(255, 82)
        btnOn.Name = "btnOn"
        btnOn.Size = New Size(75, 44)
        btnOn.TabIndex = 25
        btnOn.Text = "On"
        btnOn.UseVisualStyleBackColor = True
        ' 
        ' btnSix
        ' 
        btnSix.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSix.Location = New Point(174, 181)
        btnSix.Name = "btnSix"
        btnSix.Size = New Size(75, 44)
        btnSix.TabIndex = 26
        btnSix.Text = "6"
        btnSix.UseVisualStyleBackColor = True
        ' 
        ' btnMultiply
        ' 
        btnMultiply.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMultiply.Location = New Point(255, 231)
        btnMultiply.Name = "btnMultiply"
        btnMultiply.Size = New Size(75, 44)
        btnMultiply.TabIndex = 27
        btnMultiply.Text = "*"
        btnMultiply.UseVisualStyleBackColor = True
        ' 
        ' btnMinus
        ' 
        btnMinus.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMinus.Location = New Point(255, 181)
        btnMinus.Name = "btnMinus"
        btnMinus.Size = New Size(75, 44)
        btnMinus.TabIndex = 28
        btnMinus.Text = "-"
        btnMinus.UseVisualStyleBackColor = True
        ' 
        ' btnThree
        ' 
        btnThree.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnThree.Location = New Point(174, 132)
        btnThree.Name = "btnThree"
        btnThree.Size = New Size(75, 44)
        btnThree.TabIndex = 29
        btnThree.Text = "3"
        btnThree.UseVisualStyleBackColor = True
        ' 
        ' btnTwo
        ' 
        btnTwo.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnTwo.Location = New Point(93, 132)
        btnTwo.Name = "btnTwo"
        btnTwo.Size = New Size(75, 44)
        btnTwo.TabIndex = 30
        btnTwo.Text = "2"
        btnTwo.UseVisualStyleBackColor = True
        ' 
        ' btnAdd
        ' 
        btnAdd.Font = New Font("Stencil", 27.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnAdd.Location = New Point(255, 132)
        btnAdd.Name = "btnAdd"
        btnAdd.Size = New Size(75, 44)
        btnAdd.TabIndex = 31
        btnAdd.Text = "+"
        btnAdd.UseVisualStyleBackColor = True
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(333, 339)
        Controls.Add(btnAdd)
        Controls.Add(btnTwo)
        Controls.Add(btnThree)
        Controls.Add(btnMinus)
        Controls.Add(btnMultiply)
        Controls.Add(btnSix)
        Controls.Add(btnOn)
        Controls.Add(btnOff)
        Controls.Add(btnOne)
        Controls.Add(btnFour)
        Controls.Add(btnSeven)
        Controls.Add(btnDot)
        Controls.Add(btnEqualTo)
        Controls.Add(btnZero)
        Controls.Add(btnEight)
        Controls.Add(btnNine)
        Controls.Add(btnDivide)
        Controls.Add(btnFive)
        Controls.Add(btnClear)
        Controls.Add(txtDisplay)
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnFive As Button
    Friend WithEvents btnDivide As Button
    Friend WithEvents btnNine As Button
    Friend WithEvents btnEight As Button
    Friend WithEvents btnZero As Button
    Friend WithEvents btnEqualTo As Button
    Friend WithEvents btnDot As Button
    Friend WithEvents btnSeven As Button
    Friend WithEvents btnFour As Button
    Friend WithEvents btnOne As Button
    Friend WithEvents btnOff As Button
    Friend WithEvents btnOn As Button
    Friend WithEvents btnSix As Button
    Friend WithEvents btnMultiply As Button
    Friend WithEvents btnMinus As Button
    Friend WithEvents btnThree As Button
    Friend WithEvents btnTwo As Button
    Friend WithEvents btnAdd As Button

End Class

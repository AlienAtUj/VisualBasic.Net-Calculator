﻿
'Made by AlieN@UJ.io 
'Email Us @:AlientUJ.io@gmail.com
'Call/WhathsApp  Us @:0646268073

Public Class Form1
    Private CalcOn As Boolean = True
    Private Var1, Var2 As Double
    Private Operation As String
    Private Answer As Double
    Private notOn As Off



    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        If CalcOn = True Then
            txtDisplay.Text = ""
        End If
    End Sub

    Private Sub btnOff_Click(sender As Object, e As EventArgs) Handles btnOff.Click
        CalcOn = False

        txtDisplay.Text = "CALCULATOR OFF TURN ON FIRST"
    End Sub

    Private Sub btnOne_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        If CalcOn = True Then
            txtDisplay.Text += "1"
        End If

    End Sub

    Private Sub btnTwo_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        If CalcOn = True Then
            txtDisplay.Text += "2"
        End If
    End Sub

    Private Sub btnThree_Click(sender As Object, e As EventArgs) Handles btnThree.Click
        If CalcOn = True Then
            txtDisplay.Text += "3"
        End If
    End Sub

    Private Sub btnFour_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        If CalcOn = True Then
            txtDisplay.Text += "4"
        End If
    End Sub

    Private Sub btnFive_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        If CalcOn = True Then
            txtDisplay.Text += "5"
        End If
    End Sub

    Private Sub btnSix_Click(sender As Object, e As EventArgs) Handles btnSix.Click
        If CalcOn = True Then
            txtDisplay.Text += "6"
        End If
    End Sub

    Private Sub btnSeven_Click(sender As Object, e As EventArgs) Handles btnSeven.Click
        If CalcOn = True Then
            txtDisplay.Text += "7"
        End If
    End Sub

    Private Sub btnEight_Click(sender As Object, e As EventArgs) Handles btnEight.Click
        txtDisplay.Text += "8"
    End Sub

    Private Sub btnNine_Click(sender As Object, e As EventArgs) Handles btnNine.Click
        If CalcOn = True Then
            txtDisplay.Text += "9"
        End If
    End Sub

    Private Sub btnDot_Click(sender As Object, e As EventArgs) Handles btnDot.Click
        If CalcOn = True Then
            txtDisplay.Text += "."
        End If
    End Sub



    Private Sub btnZero_Click(sender As Object, e As EventArgs) Handles btnZero.Click
        If CalcOn = True Then
            txtDisplay.Text += "0"
        End If
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If CalcOn = True Then

            Var1 = GetNum(txtDisplay.Text)
            txtDisplay.Text = ""
            Operation = "+"

        End If

    End Sub

    Private Sub btnMinus_Click(sender As Object, e As EventArgs) Handles btnMinus.Click
        If CalcOn = True Then

            Var1 = GetNum(txtDisplay.Text)
            txtDisplay.Text = ""
            Operation = "-"

        End If

    End Sub

    Private Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        If CalcOn = True Then

            Var1 = GetNum(txtDisplay.Text)
            txtDisplay.Text = ""
            Operation = "*"

        End If

    End Sub

    Private Sub btnDivide_Click(sender As Object, e As EventArgs) Handles btnDivide.Click
        If CalcOn = True Then

            Var1 = GetNum(txtDisplay.Text)
            txtDisplay.Text = ""
            Operation = "/"

        End If
    End Sub

    Private Sub btnEqualTo_Click(sender As Object, e As EventArgs) Handles btnEqualTo.Click

        Var2 = GetNum(txtDisplay.Text)

        If CalcOn = True Then
            Select Case Operation
                Case "+"
                    Answer = Var1 + Var2
                Case "-"
                    Answer = Var1 - Var2
                Case "*"
                    Answer = Var1 * Var2
                Case "/"
                    If Var2 <> 0 Then
                        Answer = Var1 / Var2
                    Else
                        MsgBox("Error cannot Divo=ide with zero")
                        txtDisplay.Text = ""

                    End If
            End Select

            txtDisplay.Text = Answer
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        notOn = New Off("CALCULATOR OFF TURN ON FIRST")
        CalcOn = False

        txtDisplay.Text = notOn.Message
        txtDisplay.ReadOnly = True
    End Sub

    Private Sub btnOn_Click(sender As Object, e As EventArgs) Handles btnOn.Click
        CalcOn = True
        txtDisplay.Text = ""
    End Sub

    Private Function GetNum(input As String) As Double
        Dim number As Double
        If Double.TryParse(input, number) Then
            Return number
        Else
            MessageBox.Show("Invalid number entered.", "Error")
            Return 0
        End If
    End Function

End Class
